/* =========================================================
   SEIA // SECURE INTELLIGENCE NETWORK
   CLIENT-SIDE INTERFACE CONTROLLER
========================================================= */


/* =========================================================
   CONFIGURATION
========================================================= */

const ACCESS_PASSWORD = "BLACKHAWK@14";


/* =========================================================
   DOM REFERENCES
========================================================= */

const accessScreen =
    document.getElementById("accessScreen");

const mainSystem =
    document.getElementById("mainSystem");

const loginForm =
    document.getElementById("loginForm");

const accessCode =
    document.getElementById("accessCode");

const loginMessage =
    document.getElementById("loginMessage");

const showPassword =
    document.getElementById("showPassword");

const lockButton =
    document.getElementById("lockButton");

const systemClock =
    document.getElementById("systemClock");

const accessTime =
    document.getElementById("accessTime");

const terminal =
    document.getElementById("terminal");

const auditLog =
    document.getElementById("auditLog");

const agentGrid =
    document.getElementById("agentGrid");

const agentSearch =
    document.getElementById("agentSearch");

const nationalityFilter =
    document.getElementById("nationalityFilter");

const agentModal =
    document.getElementById("agentModal");

const closeModal =
    document.getElementById("closeModal");


/* =========================================================
   AGENT DATABASE
========================================================= */

const agents = [

    {
        name: "KIM SINAPUELAS",
        codename: "BLACKHAWK",
        nationality: "FILIPINO",
        role: "FIELD INTELLIGENCE OPERATIONS",
        initials: "KS"
    },

    {
        name: "NOURHEN FARHATT",
        codename: "THE EYE",
        nationality: "FILIPINO-TURKISH",
        role: "TECHNICAL SURVEILLANCE / CCTV INTELLIGENCE",
        initials: "NF"
    },

    {
        name: "ELLERIE TIU",
        codename: "SILVER FOX",
        nationality: "FILIPINO",
        role: "INTELLIGENCE ANALYSIS",
        initials: "ET"
    },

    {
        name: "MICHAEL ANGELO NUEVA ESPAÑA",
        codename: "NIGHTHAWK",
        nationality: "FILIPINO",
        role: "FIELD OPERATIONS",
        initials: "MN"
    },

    {
        name: "ANTONIO FERRER",
        codename: "IRONWOLF",
        nationality: "FILIPINO",
        role: "STRATEGIC SECURITY OPERATIONS",
        initials: "AF"
    },

    {
        name: "DARIUS NAVARRO",
        codename: "GHOSTLINE",
        nationality: "FILIPINO",
        role: "CYBER INTELLIGENCE ANALYSIS",
        initials: "DN"
    },

    {
        name: "SELENE AKYOL",
        codename: "VANTA",
        nationality: "FILIPINO-TURKISH",
        role: "SIGNALS INTELLIGENCE",
        initials: "SA"
    },

    {
        name: "MARCUS DEL ROSARIO",
        codename: "RAVEN",
        nationality: "FILIPINO",
        role: "RECONNAISSANCE INTELLIGENCE",
        initials: "MR"
    },

    {
        name: "ADRIAN YILMAZ",
        codename: "CIPHER",
        nationality: "FILIPINO-TURKISH",
        role: "CRYPTOGRAPHIC ANALYSIS",
        initials: "AY"
    },

    {
        name: "ISABEL SANTOS",
        codename: "FALCON",
        nationality: "FILIPINO",
        role: "COUNTERINTELLIGENCE",
        initials: "IS"
    },

    {
        name: "LEON CRUZ",
        codename: "SPECTER",
        nationality: "FILIPINO",
        role: "SPECIAL OPERATIONS",
        initials: "LC"
    }

];


/* =========================================================
   CLOCK
========================================================= */

function updateClock() {

    const now = new Date();

    const time = now.toLocaleTimeString(
        "en-US",
        {
            hour12: false
        }
    );

    systemClock.textContent = time;
    accessTime.textContent = time;

}


setInterval(updateClock, 1000);

updateClock();


/* =========================================================
   PASSWORD VISIBILITY
========================================================= */

showPassword.addEventListener(
    "click",
    () => {

        if (accessCode.type === "password") {

            accessCode.type = "text";

            showPassword.textContent = "HIDE";

        } else {

            accessCode.type = "password";

            showPassword.textContent = "SHOW";

        }

    }
);


/* =========================================================
   LOGIN
========================================================= */

loginForm.addEventListener(
    "submit",
    event => {

        event.preventDefault();

        const enteredPassword =
            accessCode.value.trim();


        if (
            enteredPassword ===
            ACCESS_PASSWORD
        ) {

            loginMessage.style.color =
                "#37d49a";

            loginMessage.textContent =
                "AUTHENTICATION VERIFIED // ESTABLISHING SECURE SESSION";


            setTimeout(
                () => {

                    accessScreen.style.display =
                        "none";

                    mainSystem.classList.remove(
                        "hidden"
                    );


                    addTerminal(
                        "AUTH",
                        "Operator authentication verified."
                    );


                    addTerminal(
                        "NET",
                        "Secure intelligence network established."
                    );


                    addAudit(
                        "AUTH",
                        "Operator session authenticated."
                    );


                },
                800
            );


        } else {

            loginMessage.style.color =
                "#d95362";

            loginMessage.textContent =
                "ACCESS DENIED // INVALID SECURITY CREDENTIAL";


            accessCode.value = "";


            accessScreen.animate(
                [
                    {
                        transform:
                            "translateX(0)"
                    },
                    {
                        transform:
                            "translateX(-7px)"
                    },
                    {
                        transform:
                            "translateX(7px)"
                    },
                    {
                        transform:
                            "translateX(0)"
                    }
                ],
                {
                    duration: 250
                }
            );


        }

    }
);


/* =========================================================
   LOCK SYSTEM
========================================================= */

lockButton.addEventListener(
    "click",
    lockSystem
);


function lockSystem() {

    mainSystem.classList.add("hidden");

    accessScreen.style.display =
        "flex";

    accessCode.value = "";

    loginMessage.textContent = "";

}


/* =========================================================
   NAVIGATION
========================================================= */

const navigationButtons =
    document.querySelectorAll(
        ".nav-button"
    );

const pageSections =
    document.querySelectorAll(
        ".page-section"
    );


navigationButtons.forEach(
    button => {

        button.addEventListener(
            "click",
            () => {

                const target =
                    button.dataset.section;


                navigationButtons.forEach(
                    item => {

                        item.classList.remove(
                            "active"
                        );

                    }
                );


                pageSections.forEach(
                    section => {

                        section.classList.remove(
                            "active-section"
                        );

                    }
                );


                button.classList.add(
                    "active"
                );


                document
                    .getElementById(target)
                    .classList.add(
                        "active-section"
                    );


                addAudit(
                    "NAV",
                    `Directorate accessed: ${target.toUpperCase()}`
                );

            }
        );

    }
);


/* =========================================================
   TERMINAL
========================================================= */

function addTerminal(
    type,
    message
) {

    const line =
        document.createElement("div");

    line.className =
        "terminal-line";


    line.innerHTML = `
        <span class="prompt">
            [${type}]
        </span>
        <span class="command">
            ${message}
        </span>
    `;


    terminal.appendChild(line);


    while (
        terminal.children.length > 12
    ) {

        terminal.removeChild(
            terminal.firstChild
        );

    }


    terminal.scrollTop =
        terminal.scrollHeight;

}


/* =========================================================
   AUDIT LOG
========================================================= */

function addAudit(
    type,
    message
) {

    const now =
        new Date().toLocaleTimeString(
            "en-US",
            {
                hour12: false
            }
        );


    const row =
        document.createElement("div");

    row.className =
        "audit-row";


    row.innerHTML = `

        <span class="audit-time">
            ${now}
        </span>

        <span class="audit-type">
            ${type}
        </span>

        <span class="audit-message">
            ${message}
        </span>

    `;


    auditLog.prepend(row);


    while (
        auditLog.children.length > 8
    ) {

        auditLog.removeChild(
            auditLog.lastChild
        );

    }

}


/* =========================================================
   INITIAL SYSTEM LOG
========================================================= */

const initialAudit = [

    [
        "SYS",
        "Network integrity verification completed."
    ],

    [
        "SEC",
        "Perimeter authentication services online."
    ],

    [
        "INT",
        "Regional intelligence feed synchronized."
    ],

    [
        "NET",
        "Encrypted communications channel available."
    ],

    [
        "OPS",
        "Personnel accountability confirmed."
    ],

    [
        "SYS",
        "Command interface initialized."
    ]

];


initialAudit.forEach(
    item => {

        addAudit(
            item[0],
            item[1]
        );

    }
);


const initialTerminal = [

    [
        "SYS",
        "SEIA COMMAND INTERFACE INITIALIZED."
    ],

    [
        "NET",
        "SECURE NETWORK CONNECTION ESTABLISHED."
    ],

    [
        "INT",
        "INTELLIGENCE FEEDS SYNCHRONIZED."
    ],

    [
        "OPS",
        "OPERATIONAL STATUS: NOMINAL."
    ],

    [
        "SEC",
        "SECURITY POSTURE: ELEVATED."
    ]

];


initialTerminal.forEach(
    item => {

        addTerminal(
            item[0],
            item[1]
        );

    }
);


/* =========================================================
   LIVE SYSTEM EVENTS
========================================================= */

const systemEvents = [

    [
        "NET",
        "Secure node synchronization completed."
    ],

    [
        "INT",
        "Regional intelligence feed updated."
    ],

    [
        "SEC",
        "Perimeter integrity check passed."
    ],

    [
        "OPS",
        "Operational status refreshed."
    ],

    [
        "SYS",
        "System health check completed."
    ],

    [
        "COM",
        "Encrypted communications channels operational."
    ]

];


let eventIndex = 0;


setInterval(
    () => {

        const event =
            systemEvents[eventIndex];


        addTerminal(
            event[0],
            event[1]
        );


        eventIndex++;

        if (
            eventIndex >=
            systemEvents.length
        ) {

            eventIndex = 0;

        }

    },
    4200
);


/* =========================================================
   PERSONNEL DATABASE
========================================================= */

function renderAgents() {

    const search =
        agentSearch.value
            .toLowerCase()
            .trim();


    const nationality =
        nationalityFilter.value;


    const filtered =
        agents.filter(
            agent => {

                const matchesSearch =
                    agent.name
                        .toLowerCase()
                        .includes(search) ||

                    agent.codename
                        .toLowerCase()
                        .includes(search) ||

                    agent.role
                        .toLowerCase()
                        .includes(search);


                const matchesNationality =
                    nationality === "all" ||
                    agent.nationality === nationality;


                return (
                    matchesSearch &&
                    matchesNationality
                );

            }
        );


    agentGrid.innerHTML = "";


    if (filtered.length === 0) {

        agentGrid.innerHTML = `

            <div
                style="
                    grid-column:1/-1;
                    padding:40px;
                    text-align:center;
                    color:#71827f;
                    font-family:monospace;
                "
            >
                NO PERSONNEL RECORDS MATCH THE QUERY.
            </div>

        `;

        return;

    }


    filtered.forEach(
        agent => {

            const card =
                document.createElement("article");


            card.className =
                "agent-card";


            card.innerHTML = `

                <div class="agent-avatar">
                    ${agent.initials}
                </div>

                <div class="agent-name">
                    ${agent.name}
                </div>

                <div class="agent-codename">
                    // ${agent.codename}
                </div>

                <div class="agent-role">
                    ${agent.role}
                </div>

                <div class="agent-country">
                    NATIONALITY:
                    ${agent.nationality}
                </div>

            `;


            card.addEventListener(
                "click",
                () => {

                    openAgent(agent);

                }
            );


            agentGrid.appendChild(card);

        }
    );

}


agentSearch.addEventListener(
    "input",
    renderAgents
);


nationalityFilter.addEventListener(
    "change",
    renderAgents
);


renderAgents();


/* =========================================================
   AGENT MODAL
========================================================= */

function openAgent(agent) {

    document.getElementById(
        "modalInitials"
    ).textContent =
        agent.initials;


    document.getElementById(
        "modalCodename"
    ).textContent =
        agent.codename;


    document.getElementById(
        "modalName"
    ).textContent =
        agent.name;


    document.getElementById(
        "modalNationality"
    ).textContent =
        agent.nationality;


    document.getElementById(
        "modalRole"
    ).textContent =
        agent.role;


    agentModal.classList.add(
        "visible"
    );


    addAudit(
        "PERSONNEL",
        `Personnel record accessed: ${agent.codename}`
    );

}


function closeAgentModal() {

    agentModal.classList.remove(
        "visible"
    );

}


closeModal.addEventListener(
    "click",
    closeAgentModal
);


agentModal.addEventListener(
    "click",
    event => {

        if (
            event.target ===
            agentModal
        ) {

            closeAgentModal();

        }

    }
);


/* =========================================================
   ESCAPE KEY
========================================================= */

document.addEventListener(
    "keydown",
    event => {

        if (
            event.key === "Escape"
        ) {

            closeAgentModal();

        }

    }
);


/* =========================================================
   SIMULATED SYSTEM ACTIVITY
========================================================= */

setInterval(
    () => {

        if (
            mainSystem.classList.contains(
                "hidden"
            )
        ) {

            return;

        }


        const messages = [

            "Routine security verification completed.",

            "Intelligence repository synchronization completed.",

            "Encrypted node handshake successful.",

            "Operational database integrity verified.",

            "Regional monitoring services nominal."

        ];


        const message =
            messages[
                Math.floor(
                    Math.random() *
                    messages.length
                )
            ];


        addAudit(
            "SYS",
            message
        );

    },
    8500
);